Speed test arrays here!
